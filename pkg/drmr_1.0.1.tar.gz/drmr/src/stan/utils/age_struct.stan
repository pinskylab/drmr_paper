/**
 * @title Generate theoretical mean according to the simplest model possible
 *
 * @description
 * 
 * @param n_patches number of patches
 * @param n_time number of years of training data
 * @param n_ages number of age classes
 * @param f_a_t fishing mortality at age "a" and time "t"
 * @param neg_mort minus natural mortality (instantaneous) rate
 * @param init a n_ages - 1 array.
 * @param recruitment a n_time by n_patches matrix;
 * @param init_type a n_time by n_patches matrix;
 * 
 * @return an array of numbers by age, year and patch
 */
array[] matrix simplest(int n_patches,
                        int n_time,
                        int n_ages,
                        // Mortality parameter
                        matrix f_a_t,
                        matrix neg_mort,
                        // initialization
                        array[] real init,
                        matrix recruitment,
                        int minit) {
  /*
    This function could be updated to have patches and time as the input as
    opposed to n_patches and n_time. The advantage would be that the ordering
    of these variables in the input dataset would not be important. The would
    come at the cost of increasing the complexity of the function.
   */
  // initializing output with zeros
  array[n_ages] matrix[n_time, n_patches] output
    = rep_array(rep_matrix(0.0, n_time, n_patches), n_ages);
  output[1] = recruitment;
  if (minit) {
    for (p in 1:n_patches) {
      for (a in 2:n_ages) {
        output[a, 1, p] = output[a - 1, 1, p] +
          neg_mort[2, p] - f_a_t[a - 1, 2];
      }
    }
  } else {
    for (a in 1 : (n_ages - 1)) {
      output[a + 1, 1, ] = rep_row_vector(init[a], n_patches);
    }
  }
  /* output[1] += init; */
  for (i in 2 : n_time) {
    for (p in 1 : n_patches) {
      for (a in 2 : n_ages) {
        output[a, i, p] = output[a - 1, i - 1, p] +
          neg_mort[i - 1, p] - f_a_t[a - 1, i - 1];
      }
    }
  }
  return exp(output);
}

/**
 * @title Applying movement
 *
 * @description
 * 
 * @param lambda array of number of individuals per age, time, and patch
 * @param M movement matrix
 * @param mov_age ages at which movement starts (this can be generalized)
 * 
 * @return an array of numbers by age, year and patch
 */
array[] matrix apply_movement(array[] matrix lambda, matrix M,
                              array[] int mov_age) {
  int n_ages = size(lambda);
  array[n_ages] matrix[rows(lambda[1]), cols(lambda[1])] output = lambda;
  for (a in 1:n_ages) {
    if (mov_age[a]) {
      output[a] = lambda[a] * M';
    }
  }
  return output;
}

/**
 * @title Generate theoretical mean according to the simplest model possible with movement
 *
 * @description This version includes mechanistic movement.
 * 
 * @param n_patches number of patches
 * @param n_time number of years of training data
 * @param n_ages number of age classes
 * @param f_a_t fishing mortality at age "a" and time "t"
 * @param neg_mort minus natural mortality (instantaneous) rate
 * @param init a n_ages - 1 array.
 * @param recruitment a n_time by n_patches matrix;
 * @param minit 1 if mortality is stable at the beginning
 * @param zeta probability of staying in the current site
 * @param w_adj sparse CSR vector of non-zero entries of adjacency matrix
 * @param v_adj sparse CSR array of column indices
 * @param u_adj sparse CSR array of row starting indices
 * @param mov_age ages at which movement starts
 * 
 * @return an array of numbers by age, year and patch
 */
array[] matrix simplest_movement(int n_patches,
                                 int n_time,
                                 int n_ages,
                                 matrix f_a_t,
                                 matrix neg_mort,
                                 array[] real init,
                                 matrix recruitment,
                                 int minit,
                                 real zeta,
                                 vector w_adj,
                                 array[] int v_adj,
                                 array[] int u_adj,
                                 array[] int mov_age) {
  array[n_ages] matrix[n_time, n_patches] output
    = rep_array(rep_matrix(0.0, n_time, n_patches), n_ages);
    
  // Time t=1
  output[1, 1] = exp(recruitment[1]);
  if (minit) {
    for (p in 1:n_patches) {
      for (a in 2:n_ages) {
        output[a, 1, p] = output[a - 1, 1, p] *
          exp(neg_mort[2, p] - f_a_t[a - 1, 2]);
      }
    }
  } else {
    for (a in 1 : (n_ages - 1)) {
      output[a + 1, 1] = rep_row_vector(exp(init[a]), n_patches);
    }
  }
  
  for (i in 2 : n_time) {
    // Recruitment at time i
    output[1, i] = exp(recruitment[i]);
    
    // Survival and Movement from time i-1 to i
    for (a in 2 : n_ages) {
      // Survival first (at each patch)
      row_vector[n_patches] surv = exp(neg_mort[i - 1] - f_a_t[a - 1, i - 1]);
      row_vector[n_patches] lambda_surv = output[a - 1, i - 1] .* surv;
      
      if (mov_age[a]) {
        // Mechanistic movement: survivors move
        vector[n_patches] adj_x = csr_matrix_times_vector(n_patches, n_patches, w_adj, v_adj, u_adj, lambda_surv');
        output[a, i] = (zeta * lambda_surv' + (1 - zeta) * adj_x)';
      } else {
        output[a, i] = lambda_surv;
      }
    }
  }
  return output;
}

/**
 * @title Generate theoretical mean according to a Ricker model
 *
 * @description
 * 
 * @param n_patches number of patches
 * @param n_time number of years of training data
 * @param n_ages number of age classes
 * @param f_a_t fishing mortality at age "a" and time "t"
 * @param neg_mort minus natural mortality (instantaneous) rate
 * @param init a n_ages - 1 array.
 * @param rep_age a n_ages array specifying ages that contribute to
 * recruitment.
 * @param g_r growth rate.
 * recruitment.
 * 
 * @return an array of numbers by age, year and patch
 */
// array[] matrix popricker(int n_patches,
//                          int n_time,
//                          int n_ages,
//                          // Mortality parameter
//                          matrix f_a_t,
//                          matrix neg_mort,
//                          // initialization
//                          array[] real init,
//                          array[] int rep_age,
//                          matrix g_r) {
//   // initializing output with zeros
//   array[n_ages] matrix[n_time, n_patches] output
//     = rep_array(rep_matrix(0.0, n_time, n_patches), n_ages);
//   for (p in 1:n_patches) {
//     for (i in 1:n_time) {
//       output[1, i, p] = recruitment[i, p];
//     }
//   }
//   for (a in 1 : (n_ages - 1)) {
//     output[a, 1 : a, ] = rep_matrix(to_vector(init[1 : a]), n_patches);
//   }
//   for (i in 2 : n_time) {
//     for (p in 1 : n_patches) {
//       for (a in 2 : n_ages) {
//         output[a, i, p] = output[a - 1, i - 1, p] +
//           neg_mort[i - 1, p] - f_a_t[a - 1, i - 1];
//       }
//     }
//   }
//   return exp(output);
// }
