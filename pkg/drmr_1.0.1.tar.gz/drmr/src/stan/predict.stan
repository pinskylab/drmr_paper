functions {
#include utils/age_struct.stan
#include utils/age_st_forecast.stan
#include utils/lpdfs.stan
}
data {
  //--- survey data  ---
  int N;
  int n_ages; // number of ages
  int n_sites; // number of sites
  int n_time; // years for forecasts
  int n_time_train; // years for training
  array[N] int time;
  array[N] int site;
  //--- toggles ---
  int<lower = 0, upper = 1> rho_mu;
  int<lower = 0, upper = 3> ar_re;
  int<lower = 0, upper = 3> iid_re;
  int<lower = 0, upper = 3> sp_re;
  int<lower = 0, upper = 1> movement;
  int<lower = 0, upper = 1> est_surv; // estimate mortality?
  int<lower = 0, upper = 1> cloglog; // use cloglog instead of logit for rho
  int<lower = 0, upper = 4> likelihood; // (0 = Original LN, 1 = repar LN, 2 =
                                        // Gamma, 3 = loglogistic, 4 = truncated
                                        // normal)
  int<lower = 0, upper = 2> type;
  //--- suitability (for rho) ----
  int<lower = 1> K_t;
  matrix[N, K_t] X_t;
  //--- fish mortality data ----
  matrix[n_ages, n_time] f;
  matrix[n_ages, n_time_train] f_past;
  array[est_surv ? 0 : 1] real m; // total mortality
  //--- movement related quantities ----
  matrix[movement ? n_sites: 1, movement ? n_sites : 1] adj_mat;
  int<lower = 0> n_edges_adj;
  array[movement ? n_ages : 0] int ages_movement;
  vector[n_ages] selectivity_at_age;
  //--- environmental data ----
  //--- * for mortality ----
  array[est_surv ? 1 : 0] int<lower = 1> K_m;
  matrix[est_surv ? N : 1, est_surv ? K_m[1] : 1] X_m;
  matrix[est_surv ? n_sites : 1, est_surv ? K_m[1] : 1] X_m_past;
  //--- * for recruitment ----
  int<lower = 1> K_r;
  matrix[N, K_r] X_r; 
}
transformed data {
  vector[movement ? n_edges_adj : 0] w_adj;
  array[movement ? n_edges_adj : 0] int v_adj;
  array[movement ? n_sites + 1 : 0] int u_adj;
  matrix[movement ? n_sites : 0, movement ? n_sites : 0] adj_mat_std;
  if (movement) {
    for (i in 1:n_sites) {
      real row_s = sum(adj_mat[i]);
      if (row_s > 0) {
        adj_mat_std[i] = adj_mat[i] / row_s;
      } else {
        adj_mat_std[i] = adj_mat[i];
      }
    }
    w_adj = csr_extract_w(adj_mat_std);
    v_adj = csr_extract_v(adj_mat_std);
    u_adj = csr_extract_u(adj_mat_std);
  }
}
parameters {
  //--- "regression" coefficients for absence and recr ----
  vector[K_t] beta_t;
  vector[K_r] beta_r;
  //--- pop dyn parameters ----
  matrix[n_ages, n_sites] lambda;
  //--- rel between rho and mu ----
  array[rho_mu] real xi;
  //--- additional parameter for different lik functions ----
  array[likelihood > 0 ? 1 : 0] real phi;
  array[likelihood == 0 ? 1 : 0] real sigma_obs;
  //--- movement ----
  array[movement] real zeta;
  //--- reg for mortality ---
  array[est_surv] vector[est_surv ? K_m[1] : 0] beta_s;
  //--- parameters from AR process ----
  vector[ar_re > 0 ? n_time_train : 0] z_t;
  array[ar_re > 0 ? 1 : 0] real alpha;
  array[ar_re > 0 ? 1 : 0] real sigma_t;
  //--- IID RE ----
  array[iid_re > 0 ? 1 : 0] vector[n_sites] z_i;
  //--- SP RE ----
  vector[sp_re > 0 ? n_sites : 0] z_s;
}
generated quantities {
  //--- projected total density ----
  vector[N] y_proj;
  //--- lambda_proj calculations ----
  {
    //--- projected expected density ----
    vector[N] mu_proj;
    //--- projected absence probability ----
    vector[N] rho_proj;
    //--- AR term ----
    vector[ar_re > 0 ? n_time : 0] z_tp;
    if (ar_re > 0) {
      {
        vector[n_time] w_t;
        w_t[1] = std_normal_rng();
        z_tp[1] = alpha[1] * z_t[n_time_train] +
          sigma_t[1] * w_t[1];
        for (tp in 2:n_time) {
          w_t[tp] = std_normal_rng();
          z_tp[tp] = alpha[1] * z_tp[tp - 1] +
            sigma_t[1] * w_t[tp];
        }
      }
    }
    //--- projected expected density by age ---
    array[n_ages] matrix[n_time, n_sites] lambda_proj;
    vector[N] log_rec;
    log_rec = X_r * beta_r;
    if (ar_re == 1) {
      for (n in 1:N)
        log_rec[n] += z_tp[time[n]];
    }
    if (iid_re == 1) {
      for (n in 1:N)
        log_rec[n] += z_i[1][site[n]];
    }
    if (sp_re == 1) {
      for (n in 1:N)
        log_rec[n] += z_s[site[n]];
    }
    vector[n_sites] past_m;
    matrix[n_time, n_sites] current_m;
    vector[n_time * n_sites] m_aux;
    if (!est_surv) {
      current_m = rep_matrix(- m[1], n_time, n_sites);
      past_m = rep_vector(- m[1], n_sites);
    } else {
      m_aux = X_m * beta_s[1];
      if (ar_re == 2) {
        for (n in 1:N)
          m_aux[n] += z_tp[time[n]];
      }
      if (iid_re == 2) {
        for (n in 1:N)
          m_aux[n] += z_i[1][site[n]];
      }
      if (sp_re == 2) {
        for (n in 1:N)
          m_aux[n] += z_s[site[n]];
      }
      current_m = to_matrix(-log1p(exp(-m_aux)), n_time, n_sites);
      past_m = -log1p(exp(X_m_past * beta_s[1]));
    }
    if (movement) {
      //--- movement matrix ---
      lambda_proj =
        forecast_simplest_movement(n_sites,
                                   n_time,
                                   n_ages,
                                   f,
                                   current_m,
                                   to_matrix(log_rec,
                                             n_time,
                                             n_sites),
                                   lambda,
                                   f_past,
                                   past_m,
                                   zeta[1], w_adj, v_adj, u_adj,
                                   ages_movement);
    } else {
      lambda_proj = forecast_simplest(n_sites,
                                      n_time,
                                      n_ages,
                                      f,
                                      current_m,
                                      to_matrix(log_rec,
                                                n_time,
                                                n_sites),
                                      lambda,
                                      f_past,
                                      past_m);
    }
    //--- mu_proj calculations ----
    matrix[n_time, n_sites] mu_aux =
      rep_matrix(0.0, n_time, n_sites);
    //--- filling mu ----
    for (tp in 1 : n_time) {
      for (p in 1 : n_sites) {
        real mu_aux2;
        mu_aux2 = dot_product(to_vector(lambda_proj[1:n_ages, tp, p]),
                              selectivity_at_age);
        if (!is_nan(mu_aux2)) {
          mu_aux[tp, p] = mu_aux2;
        }
      } // close sites
    }
    mu_proj = to_vector(mu_aux);
    if (ar_re == 3) {
      for (n in 1:N)
        mu_proj[n] *= exp(z_tp[time[n]]);
    }
    if (iid_re == 3) {
      for (n in 1:N)
        mu_proj[n] *= exp(z_i[1][site[n]]);
    }
    if (sp_re == 3) {
      for (n in 1:N)
        mu_proj[n] *= exp(z_s[site[n]]);
    }
    //--- absence probabilities ----
    if (cloglog) {
      if (rho_mu) {
        rho_proj =
          inv_cloglog(X_t * beta_t + xi[1] .* log(mu_proj));
      } else {
        rho_proj =
          inv_cloglog(X_t * beta_t);
      }
    } else {
      if (rho_mu) {
        rho_proj =
          inv_logit(X_t * beta_t + xi[1] .* log(mu_proj));
      } else {
        rho_proj =
          inv_logit(X_t * beta_t);
      }
    }
    //--- y_proj calculations ----
    if (type == 0) {
      for (n in 1:N) {
        y_proj[n] = drmsdm_rng(mu_proj[n], rho_proj[n],
                               likelihood == 0 ? sigma_obs[1] : phi[1],
                               likelihood);
      }
    } else if (type == 1) {
      for (n in 1:N) {
        y_proj[n] = mu_proj[n] * (1 - rho_proj[n]);
      }
    } else if (type == 2) {
      for (n in 1:N) {
        y_proj[n] = mu_proj[n];
      }
    }
  }
}
