```bash
   --- Translating Stan model to C++ code ---
   bin/stanc --include-paths=/private/var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpVD3UMX/devtools_install_23297412d0ff/00LOCK-drmr/00new/drmr/bin/stan --name='lambda_gq_model' --o=/var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpHfbxOe/model-238451f203ad.hpp /var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpHfbxOe/model-238451f203ad.stan
Semantic error in '/private/var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpVD3UMX/devtools_install_23297412d0f   Semantic error in '/private/var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpVD3UMX/devtools_install_23297412d0ff/00LOCK-drmr/00new/drmr/bin/stan/utils/age_st_forecast.stan', line 98, column 50, included from
   '/var/folders/s3/skbnpfgx4ws029c69w023f740000gn/T/RtmpHfbxOe/model-238451f203ad.stan', line 3, column 0:
      -------------------------------------------------
       96:        if (i == 1) {
       97:          lambda_prev = to_row_vector(lambda_past[a - 1]);
       98:          surv = exp(to_row_vector(neg_mort_past) - to_row_vector(f_past[a - 1, past_last_time]));
                                                              ^
       99:        } else {
      100:          lambda_prev = output[a - 1, i - 1];
      -------------------------------------------------
   
   Ill-typed arguments supplied to function "to_row_vector":
   (real)
   Available signatures:
   (vector) => row_vector
     The first argument must be vector but got real
   (row_vector) => row_vector
     The first argument must be row_vector but got real
   (matrix) => row_vector
     The first argument must be matrix but got real
   (array[] real) => row_vector
     The first argument must be array[] real but got real
   (complex_vector) => complex_row_vector
     The first argument must be complex_vector but got real
   (Additional signatures omitted)
```
