## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data
data(sum_fl)


## -----------------------------------------------------------------------------
#| label: split
## 5 years-ahead predictions
first_year_forecast <- max(sum_fl$year) - 5

first_id_forecast <-
  first_year_forecast - min(sum_fl$year) + 1

years_all <- length(unique(sum_fl$year))
years_train <- years_all[years_all < first_id_forecast]
years_test <- years_all[years_all >= first_id_forecast]

## splitting data
dat_test <- sum_fl |>
  filter(year >= first_year_forecast)

dat_train <- sum_fl |>
  filter(year < first_year_forecast)


## -----------------------------------------------------------------------------
#| label: ytransform
dat_train <- dat_train |>
  mutate(dens = y / area_km2,
         .before = y)

dat_test <- dat_test |>
  mutate(dens = y / area_km2,
         .before = y)


## -----------------------------------------------------------------------------
#| label: data-format

head(dat_train[, c("year", "patch",  "y", "stemp")],
     n = 10)
tail(dat_train[, c("year", "patch",  "y", "stemp")],
     n = 10)


## -----------------------------------------------------------------------------
#| label: fit_drm
#| eval: true
my_drm <-
  fit_drm(.data = dat_train,
          y_col = "dens",
          time_col = "year",
          site_col = "patch",
          n_ages = 8,
          m = 0.25,
          seed = 2025)


## -----------------------------------------------------------------------------
#| label: summary_drm

summary(my_drm)


## -----------------------------------------------------------------------------
#| label: mcmc_combo
draws(my_drm) |>
  mcmc_combo(combo = c("trace", "dens_overlay"),
             facet_args = list(labeller = label_parsed))


## -----------------------------------------------------------------------------
#| label: update_method
#| eval: false

# my_drm2 <-
#   update(my_drm,
#          formula_zero = ~ 1 + n_hauls,
#          formula_rec = ~ 1 + stemp + I(stemp * stemp), ## establising a
#                                                        ## quadratic relationship
#                                                        ## between recruitment and stemp
#          .toggles = list(ar_re = "rec"), ## adding an autoregressive term to recruitment
#          algo_args = list(parallel_chains = 4)) ## the `algo_args` is a list
#                                                 ## that allows us to modify the
#                                                 ## parameters of the MCMC
#                                                 ## algorithm

