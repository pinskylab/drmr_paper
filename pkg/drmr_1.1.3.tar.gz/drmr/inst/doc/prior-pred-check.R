## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
data(sum_fl)


## -----------------------------------------------------------------------------
#| label: prior-pred

set.seed(2026)
pp <- prior_pred_drm(sum_fl,
                     time_col = "year",
                     site_col = "patch",
                     n_draws = 100,
                     formula_zero = ~ 1 + c_hauls,
                     formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
                     n_ages = 4)
pp


## -----------------------------------------------------------------------------
#| label: dim

dim(pp$y_rep)


## -----------------------------------------------------------------------------
#| label: drop-nonfinite

y_rep <- pp$y_rep[!pp$nonfinite, , drop = FALSE]


## -----------------------------------------------------------------------------
#| label: prop-zero

summary(rowMeans(y_rep == 0))
mean(pp$data$dens == 0)


## -----------------------------------------------------------------------------
#| label: max-dens

quantile(apply(y_rep, 1, max), probs = c(0.05, 0.5, 0.95))
max(pp$data$dens)


## -----------------------------------------------------------------------------
#| label: effects

eff <- effects_drm(pp, process = "rec", variable = "c_stemp")
plot(eff)


## -----------------------------------------------------------------------------
#| label: new-priors

set.seed(2026)
pp2 <- prior_pred_drm(sum_fl,
                      time_col = "year",
                      site_col = "patch",
                      n_draws = 500,
                      formula_zero = ~ 1 + c_hauls,
                      formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
                      n_ages = 4,
                      .priors = list(pr_beta_r_mu = c(0, 0, -1),
                                     pr_beta_r_sd = c(1, 1, .5)))
plot(effects_drm(pp2, process = "rec", variable = "c_stemp"))

