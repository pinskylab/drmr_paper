## -----------------------------------------------------------------------------
#| label: setup
#| results: hide

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data-load

## loads the data
data(sum_fl)

## splitting data for 5 years-ahead predictions
dat_test <- sum_fl |>
  filter(!train_flag)

dat_train <- sum_fl |>
  filter(train_flag)


## -----------------------------------------------------------------------------
#| label: mortality_rates

fmat <-
  system.file("fmat.rds", package = "drmr") |>
  readRDS()

years_train <- unique(dat_train$time + 1)
years_test  <- unique(dat_test$time + 1)

## splitting between train and test for model assessment
f_train <- fmat[, years_train]
f_test  <- fmat[, years_test]


## -----------------------------------------------------------------------------
#| label: adj_mat

## loading map
shp_sum_fl <- system.file("maps/sum_fl.shp", package = "drmr") |>
  st_read()

## constructing adjacency matrix
adj_mat <- gen_adj(st_buffer(st_geometry(shp_sum_fl),
                             dist = 2500))

## patch areas (km^2), named by patch
patch_areas <- sum_fl |>
  distinct(patch, area_km2)
patch_areas <- setNames(patch_areas$area_km2, patch_areas$patch)


## -----------------------------------------------------------------------------
#| label: drm_rec

algo_args <- list(parallel_chains = 2,
                  chains = 2,
                  iter_sampling = 200,
                  iter_warmup = 500,
                  show_messages = FALSE,
                  show_exceptions = FALSE)

drm_rec <-
  fit_drm(.data = dat_train,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch",
          family = "gamma",
          seed = 2026,
          formula_zero = ~ 1 + c_hauls,
          formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
          formula_surv = ~ 1,
          f_mort = f_train,
          n_ages = NROW(f_train),
          adj_mat = adj_mat, ## A matrix for movement routine
          areas = patch_areas, ## patch areas for movement
          ages_movement = c(0, 0,
                            rep(1, 8),
                            rep(0, 6)), ## ages 3 to 10 move
          .toggles = list(ar_re = "rec",
                          movement = 1,
                          est_surv = 1,
                          est_init = 0,
                          minit = 1),
          algo_args = algo_args)


## -----------------------------------------------------------------------------
#| label: drm_srv

drm_srv <-
  update(drm_rec,
         formula_rec = ~ 1,
         formula_surv = ~ 1 + c_btemp + I(c_btemp * c_btemp))


## -----------------------------------------------------------------------------
#| label: ppc2

par(mfcol = c(2, 2))
ppc(drm_rec, transform = "log1p")
ppc(drm_rec, type = "ecdf")
ppc(drm_srv, transform = "log1p")
ppc(drm_srv, type = "ecdf")


## -----------------------------------------------------------------------------
#| label: env_dem

effects_drm(drm_rec, ## model
            process = "rec", ## demographic process
            variable = "c_stemp", ## environmental variable
            prob = .8) |> ## mass of the creible interval
  plot()

effects_drm(drm_srv, ## model
            process = "surv", ## demographic process
            variable = "c_btemp", ## environmental variable
            prob = .8) |> 
  plot()


## -----------------------------------------------------------------------------
#| label: custom_envdem

multiple_cis <-
  effects_drm(drm_srv, process = "surv", variable = "c_btemp",
       summary = FALSE,
       n_pts = 200) |>
  lapply(c(0.6, 0.8, 0.9, 0.99),
         \(pr, .dt) {
           alpha <- (1 - pr) / 2
           probs <- c(alpha, 1 - alpha)
           .dt |>
             group_by(c_btemp) |>
             summarise(srv = median(survival),
                       low = quantile(survival, probs = probs[1]),
                       upp = quantile(survival, probs = probs[2])) |>
             ungroup() |>
             mutate(prob_mass = pr)
         }, .dt = _) |>
  bind_rows() |>
  mutate(c_btemp = c_btemp + mean(dat_train$btemp))

ggplot(data = multiple_cis,
       aes(x = c_btemp,
           group = factor(prob_mass,
                          levels = rev(levels(factor(prob_mass)))))) +
  geom_rug(data = dat_train,
           aes(x = btemp),
           inherit.aes = FALSE,
           alpha = 0.3,
           length = unit(0.02, "npc"),
           colour = "grey40") +
  geom_ribbon(aes(ymin = low, ymax = upp,
                  fill = factor(prob_mass,
                                levels = rev(levels(factor(prob_mass))))),
              colour = NA) +
  geom_line(aes(y = srv), linewidth = 0.6, colour = "white") +
  scale_fill_manual(
    values = c("0.99" = "#d1e5f0",
               "0.9"  = "#6baed6",
               "0.8"  = "#2171b5",
               "0.6"  = "#08306b"),
    labels = \(x) paste0(as.numeric(x) * 100, "%")
  ) +
  labs(x    = "Sea bottom temperature",
       y    = "Survival",
       fill = "Credible interval") +
  theme_minimal(base_size = 13) +
  theme(
      legend.position  = "inside",
      legend.position.inside = c(.2, .75),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = "grey90")
  )


## -----------------------------------------------------------------------------
#| label: fitted

fitted_rec <- fitted(drm_rec) |>
  summary() |>
  ## creating a column that identifies the model
  mutate(model = "rec", .before = 1) 

fitted_srv <- fitted(drm_srv) |>
  summary() |>
  ## creating a column that identifies the model
  mutate(model = "srv", .before = 1) 


## -----------------------------------------------------------------------------
#| label: preds

predicted_rec <- predict(drm_rec,
                         newdata = dat_test,
                         past_data = filter(dat_train,
                                            year == max(year)),
                         seed = 2026,
                         f_test = f_test) |>
  summary() |>
   ## creating a column that identifies the model 
  mutate(model = "rec", .before = 1)

predicted_srv <- predict(drm_srv,
                         newdata = dat_test,
                         past_data = filter(dat_train,
                                            year == max(year)),
                         seed = 2026,
                         f_test = f_test) |>
  summary() |>
  ## creating a column that identifies the model
  mutate(model = "srv", .before = 1) 


## -----------------------------------------------------------------------------
#| label: bind_and_join

combined_sfl <-
  bind_rows(fitted_rec, predicted_rec,
            fitted_srv, predicted_srv) |>
  mutate(patch = as.integer(patch)) |>
  left_join(sum_fl, by = c("patch", "year"))


ggplot(data = combined_sfl,
       aes(x = year)) +
  geom_ribbon(aes(ymin = q5, ymax = q95),
              alpha = .5) +
  geom_line(aes(y = q50)) +
  geom_point(aes(y = dens), color = 2, pch = 19)+ 
  facet_grid(model ~ patch, scales = "free_y") +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: rmse

combined_sfl <-
  combined_sfl |>
  mutate(type = ifelse(train_flag,
                       "out-of-sample",
                       "in-sample"))

combined_sfl |>
  mutate(mse = dens - q50) |>
  mutate(mse = mse * mse) |>
  group_by(type, model) |>
  summarise(rmse = sqrt(mean(mse))) |>
  knitr::kable()


## -----------------------------------------------------------------------------
#| label: latent

fitted_rl <- fitted(drm_rec, type = "latent") |>
  summary() 

predicted_rl <- predict(drm_rec,
                        newdata = dat_test,
                        past_data = filter(dat_train,
                                           year == max(year)),
                        seed = 2026,
                        f_test = f_test,
                        type = "latent") |>
  summary()

combined_rl <- bind_rows(fitted_rl, predicted_rl)


## -----------------------------------------------------------------------------
#| label: viz_latent
combined_rl |>
  mutate(patch = as.integer(patch)) |>
  ## to allow for a comparison with reality
  left_join(sum_fl, by = c("patch", "year")) |>
  ggplot(data = _,
         aes(x = year)) +
  geom_ribbon(aes(ymin = q5, ymax = q95),
              alpha = .5) +
  geom_line(aes(y = q50)) +
  geom_point(aes(y = dens), color = 2, pch = 19)+ 
  facet_grid(. ~ patch, scales = "free_y") +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: edens

lambdas <- ages_edens(drm_rec) |>
  summary() |>
  mutate(patch = as.integer(patch))


## -----------------------------------------------------------------------------
#| label: edens_year

lambdas |>
  filter(year == 2010) |>  
  ggplot(data = _,
         aes(x = age)) +
  geom_segment(aes(xend = age, y = 0, yend = q50),
               color = "gray50") +
  geom_errorbar(aes(ymin = q5, ymax = q95)) +
  geom_point(aes(y = q50)) +
  facet_wrap(~ patch) +
  theme_bw()



## -----------------------------------------------------------------------------
#| label: edens_patch

lambdas |>
  filter(patch == 5) |>
  filter(year %in% seq(1985, 2020, by = 5)) |>
  ggplot(data = _,
         aes(x = age)) +
  geom_segment(aes(xend = age, y = 0, yend = q50),
               color = "gray50") +
  geom_errorbar(aes(ymin = q5, ymax = q95)) +
  geom_point(aes(y = q50)) +
  facet_wrap(~ year) +
  theme_bw()


