## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)


## -----------------------------------------------------------------------------
#| label: data
data(sum_fl)


## -----------------------------------------------------------------------------
#| label: data-format

head(sum_fl[, c("year", "patch",  "y", "stemp")],
     n = 10)
tail(sum_fl[, c("year", "patch",  "y", "stemp")],
     n = 10)


## -----------------------------------------------------------------------------
#| label: fit_drm
#| eval: true
my_drm <-
  fit_drm(.data = sum_fl,
          y_col = "dens",
          time_col = "year",
          site_col = "patch",
          n_ages = 8,
          m = 0.25,
          seed = 2025)


## -----------------------------------------------------------------------------
#| label: summary_drm

summary(my_drm)


## -----------------------------------------------------------------------------
#| label: mcmc_combo
draws(my_drm) |>
  mcmc_combo(combo = c("trace", "dens_overlay"),
             facet_args = list(labeller = label_parsed))


## -----------------------------------------------------------------------------
#| label: update_method
#| eval: false

# my_drm2 <-
#   update(my_drm,
#          formula_zero = ~ 1 + n_hauls,
#          formula_rec = ~ 1 + stemp + I(stemp * stemp), ## establising a
#                                                        ## quadratic relationship
#                                                        ## between recruitment and stemp
#          .toggles = list(ar_re = "rec"), ## adding an autoregressive term to recruitment
#          algo_args = list(parallel_chains = 4)) ## the `algo_args` is a list
#                                                 ## that allows us to modify the
#                                                 ## parameters of the MCMC
#                                                 ## algorithm

