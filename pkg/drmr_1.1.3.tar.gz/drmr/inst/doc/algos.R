## -----------------------------------------------------------------------------
#| label: setup

library(drmr)
library(sf) ## "mapping"
library(ggplot2) ## graphs
library(bayesplot) ## and more graphs
library(dplyr)

## loads the data
data(sum_fl)

## mortality rates
fmat <-
  system.file("fmat.rds", package = "drmr") |>
  readRDS()

shp_sum_fl <- system.file("maps/sum_fl.shp", package = "drmr") |>
  st_read()

## constructing adjacency matrix
adj_mat <- gen_adj(st_buffer(st_geometry(shp_sum_fl),
                             dist = 2500))

## patch areas (km^2), named by patch
patch_areas <- sum_fl |>
  distinct(patch, area_km2)
patch_areas <- setNames(patch_areas$area_km2, patch_areas$patch)


## -----------------------------------------------------------------------------
#| label: nuts

nuts_args <- list(parallel_chains = 2,
                  chains = 2,
                  iter_sampling = 500,
                  iter_warmup = 500,
                  show_messages = FALSE,
                  show_exceptions = FALSE)

drm_nuts <-
  fit_drm(.data = sum_fl,
          y_col = "dens", ## response variable: density
          time_col = "year", ## vector of time points
          site_col = "patch",
          family = "gamma",
          seed = 2026,
          formula_zero = ~ 1 + c_hauls,
          formula_rec = ~ 1 + c_stemp + I(c_stemp * c_stemp),
          formula_surv = ~ 1,
          f_mort = fmat[, -1],
          n_ages = NROW(fmat),
          adj_mat = adj_mat, ## A matrix for movement routine
          areas = patch_areas, ## patch areas for movement
          ages_movement = c(0, 0,
                            rep(1, 8),
                            rep(0, 6)), ## ages 3 to 10 move
          .toggles = list(movement = 1,
                          est_surv = 1,
                          est_init = 0,
                          minit = 1),
          algo_args = nuts_args)


## -----------------------------------------------------------------------------
#| label: advi
#| eval: true

## in our tests, this algorithm has been the least stable so far.

advi_args <- list(show_messages = FALSE,
                  show_exceptions = FALSE,
                  iter = 10^4, ## maximum number of iterations (optimization)
                  draws = 4000) ## number of samples from the posterior

drm_advi <-
  update(drm_nuts,
         algo_args = advi_args,
         algorithm = "vb") ## vb stands for variational Bayes


## -----------------------------------------------------------------------------
#| label: pathfinder

path_args <- list(show_messages = FALSE,
                  show_exceptions = FALSE,
                  max_lbfgs_iters = 10^4)

drm_path <-
  update(drm_nuts,
         algo_args = path_args,
         algorithm = "pathfinder")


## -----------------------------------------------------------------------------
#| label: laplace

lapl_args <- list(show_messages = FALSE,
                  show_exceptions = FALSE)

drm_lapl <-
  update(drm_nuts,
         algo_args = lapl_args,
         algorithm = "laplace")


## -----------------------------------------------------------------------------
#| label: parest

bind_rows(
    mutate(summary(drm_nuts)$estimates, algo = "nuts"),
    mutate(summary(drm_advi)$estimates, algo = "advi"),
    mutate(summary(drm_path)$estimates, algo = "path"),
    mutate(summary(drm_lapl)$estimates, algo = "lapl")
) |>
  ggplot(data = _,
         aes(x = q50,
             y = algo)) +
  geom_linerange(aes(xmin = q5, xmax = q95)) +
  geom_point() +
  facet_wrap(~ variable, scales = "free_x") +
  theme_bw()


## -----------------------------------------------------------------------------
#| label: envrec
#| layout-ncol: 2
#| layout-nrow: 2

effects_drm(drm_nuts, "rec", "c_stemp") |>
  plot() +
  labs(title = "nuts")

effects_drm(drm_path, "rec", "c_stemp") |>
  plot() +
  labs(title = "path")

effects_drm(drm_advi, "rec", "c_stemp") |>
  plot() +
  labs(title = "advi")

effects_drm(drm_lapl, "rec", "c_stemp") |>
  plot() +
  labs(title = "lapl")

