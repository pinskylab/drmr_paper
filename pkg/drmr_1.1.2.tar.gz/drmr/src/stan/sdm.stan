functions {
#include utils/lpdfs.stanfunctions
#include utils/icar.stanfunctions
}
data {
  //--- survey data  ---
  int N; // n_sites * n_time
  int n_sites; // number of sites
  int n_time; // years for training
  array[N] int<lower = 1, upper = n_time> time;
  array[N] int<lower = 1, upper = n_sites> site;
  vector[N] y;
  //--- for vectorizing zero-inflation ----
  int N_nz;
  int N_z;
  array[N_nz] int id_nz;
  array[N_z] int id_z;
  //--- toggles ---
  int<lower = 0, upper = 1> rho_mu;
  int<lower = 0, upper = 1> ar_re;
  int<lower = 0, upper = 1> iid_re;
  int<lower = 0, upper = 1> sp_re;
  int<lower = 0, upper = 1> cloglog; // use cloglog instead of logit for rho
  int<lower = 0, upper = 4> likelihood; // (0 = Original LN, 1 = repar LN, 2 =
                                        // Gamma, 3 = log-Logistic, 4 = truncated normal)
  //--- suitability (for rho) ----
  int<lower = 1> K_z;
  matrix[N, K_z] Z;
  //--- for spatial random effects ----
  array[sp_re > 0 ? 1 : 0] int<lower = 0> N_edges;  // number of neighbor pairs
  array[sp_re > 0 ? 2 : 1,
        sp_re > 0 ? N_edges[1] : 1]
  int<lower = 1, upper = n_sites> neighbors;  // columnwise adjacent
  // scaling factor of each site's connected component (1 if no neighbors)
  vector<lower = 0>[sp_re > 0 ? n_sites : 0] scaling;
  // connected components with 2+ sites: number, sizes, and the sites
  // ordered by component (sites with no neighbors last)
  int<lower = 0> n_comp_s;
  array[n_comp_s] int<lower = 2> comp_size_s;
  array[sp_re > 0 ? n_sites : 0]
  int<lower = 1, upper = n_sites> comp_order_s;
  //--- environmental data ----
  //--- * for counts ----
  int<lower = 1> K_x;
  matrix[N, K_x] X;
  //--- priors hyperparameters ----
  real pr_sigma_obs_mu; 
  real pr_sigma_obs_sd; // formerly sigma_obs_cv
  real pr_phi_a; // revise this. It is for phi in gamma, loglogistic, and
                 // inverse-gaussian
  real pr_phi_b;
  // * now AR SD parameters have pcpriors
  real pr_lsigma_t_mu; 
  real pr_lsigma_t_sd;
  real pr_lsigma_i_mu; 
  real pr_lsigma_i_sd;
  real pr_lsigma_s_mu; 
  real pr_lsigma_s_sd;
  real pr_alpha_mu; 
  real pr_alpha_sd;
  real pr_lmxi_mu;
  real pr_lmxi_sd;
  vector[K_z] pr_beta_t_mu;
  vector[K_z] pr_beta_t_sd;
  vector[K_x] pr_beta_r_mu;
  vector[K_x] pr_beta_r_sd;
}
transformed data {
  //--- scaling factors ----
  real s_iid = sqrt(n_sites / (n_sites - 1.0));
  //--- ICAR: number of sites with no neighbors ----
  int n_single_s = sp_re > 0 ? n_sites - sum(comp_size_s) : 0;
}
parameters {
  // relationship between mu and rho
  array[rho_mu] real lxi;
  // parameter associated to the likelihood 
  array[likelihood == 0 ? 1 : 0] real<lower = 0> sigma_obs;
  // (log-logistic requires phi > 1 for its mean to be finite)
  array[likelihood > 0 ? 1 : 0] real<lower = (likelihood == 3 ? 1 : 0)> phi;
  // coefficients for recruitment (it is a log-linear model)
  vector[K_x] beta_r;
  // parameter associated with "encounter probability"
  vector[K_z] beta_t;
  //--- * AR process parameters ----
  // conditional SD
  array[ar_re] real log_sigma_t;
  // autocorrelation
  array[ar_re] real atanh_alpha;
  // aux latent variable
  vector[ar_re ? n_time : 0] w_t;
  //--- * IID RE ----
  // SD
  array[iid_re] real log_sigma_i;
  // aux latent variable
  array[iid_re] sum_to_zero_vector[n_sites] z_i;
  //--- * ICAR RE ----
  // unconstrained values; w_s (transformed parameters) sums to zero
  // within each connected component
  vector[sp_re > 0 ? n_sites - n_comp_s : 0] w_s_raw;
  array[sp_re] real log_sigma_s;
}
transformed parameters {
  // relationship between mu and rho
  array[rho_mu] real xi;
  if (rho_mu)
    xi = - exp(lxi);
  //--- AR process ----
  array[ar_re] real sigma_t;
  array[ar_re > 0 ? 1 : 0] real alpha;
  vector[ar_re ? n_time : 0] z_t;
  {
    if (ar_re) {
      alpha[1] = tanh(atanh_alpha[1]);
      sigma_t[1] = exp(log_sigma_t[1]);
      z_t[1] = sigma_t[1] * w_t[1];
      for (tp in 2:n_time) {
        z_t[tp] = alpha[1] * z_t[tp - 1] +
          sigma_t[1] * w_t[tp];
      }
    }
  }
  //--- IID RE ----
  array[iid_re > 0 ? 1 : 0] real sigma_i;
  if (iid_re > 0) {
    sigma_i[1] = exp(log_sigma_i[1]);
  }
  //--- ICAR RE ----
  array[sp_re > 0 ? 1 : 0] real sigma_s;
  vector[sp_re > 0 ? n_sites : 0] w_s;
  vector[sp_re > 0 ? n_sites : 0] z_s;
  if (sp_re > 0) {
    w_s = icar_constrain(w_s_raw, n_sites, comp_size_s, comp_order_s);
    sigma_s[1] = exp(log_sigma_s[1]);
    // scaled so that sigma_s is a typical marginal SD of z_s: the geometric
    // mean of the marginal variances in each component is sigma_s^2
    z_s = sigma_s[1] * w_s ./ sqrt(scaling);
  }
  //--- quantities used in the likelihood ----
  // probability of encounter at specific time/site combinations
  vector[N] rho;
  // Expected density at specific time/site combinations
  vector[N] mu =
    rep_vector(0.0, N);
  // rho now hasa "regression like" type
  {
    vector[N] lmu;
    lmu = X * beta_r;
    if (ar_re) {
      lmu += z_t[time];
    }
    if (sp_re) {
      lmu += z_s[site];
    }
    if (iid_re) {
      lmu += z_i[1][site];
    }
    if (cloglog) {
      if (rho_mu) {
      rho =
        inv_cloglog(Z * beta_t + xi[1] .* lmu);
      } else {
      rho =
        inv_cloglog(Z * beta_t);
      }
    } else {
      if (rho_mu) {
      rho =
        inv_logit(Z * beta_t + xi[1] .* lmu);
      } else {
        rho =
          inv_logit(Z * beta_t);
      }
    }
    mu = exp(lmu);
  }
}
// close transformed parameters block
model {
  //--- rel between rho and mu ----
  if (rho_mu)
    target += normal_lpdf(lxi[1] | pr_lmxi_mu, pr_lmxi_sd);
  //--- AR process ----
  if (ar_re) {
    target += std_normal_lpdf(w_t);
    target += normal_lpdf(log_sigma_t[1] | pr_lsigma_t_mu, pr_lsigma_t_sd);
    target += normal_lpdf(atanh_alpha[1] | pr_alpha_mu, pr_alpha_sd);
  }
  //--- IID RE ----
  if (iid_re) {
    target += normal_lpdf(log_sigma_i[1] | pr_lsigma_i_mu, pr_lsigma_i_sd);
    target += normal_lpdf(z_i[1] | 0, sigma_i[1] * s_iid);
  }
  //--- SP RE ----
  if (sp_re) {
    target += normal_lpdf(log_sigma_s[1] | pr_lsigma_s_mu, pr_lsigma_s_sd);
    // ICAR prior (each pair of neighbors appears once)
    target += -0.5 * dot_self(w_s[neighbors[1]] - w_s[neighbors[2]]);
    // sites with no neighbors: independent standard normal
    if (n_single_s > 0) {
      target += std_normal_lpdf(
        w_s[comp_order_s[(n_sites - n_single_s + 1):n_sites]]);
    }
  }
  //--- Counts ----
  target += normal_lpdf(beta_r | pr_beta_r_mu, pr_beta_r_sd);
  //--- Suitability ----
  target += normal_lpdf(beta_t | pr_beta_t_mu, pr_beta_t_sd);
  //--- Likelihood ----
  if (likelihood == 0) {
    target += normal_lpdf(sigma_obs[1] | pr_sigma_obs_mu, pr_sigma_obs_sd) -
      1.0 * normal_lccdf(0 | pr_sigma_obs_mu, pr_sigma_obs_sd);
  } else {
    // change these parameters (PC prior for exponential?)
    target += gamma_lpdf(phi[1] | pr_phi_a, pr_phi_b);
    if (likelihood == 3) {
      target += - gamma_lccdf(1 | pr_phi_a, pr_phi_b);
    }
  }
  // only evaluate density if there are length comps to evaluate
  target += ziloglik_lpdf(y | likelihood, N_nz, N,
                          id_nz, id_z,
                          mu, rho,
                          likelihood == 0 ? sigma_obs[1] : phi[1]);
}
generated quantities {
}
