functions {
#include utils/lpdfs.stanfunctions
}
data {
  //--- survey data  ---
  int N; // n_sites * n_time
  int n_ages; // number of ages
  int n_sites; // number of sites
  int n_time; // years for training
  //--- toggles ---
  vector[N] y;
  int<lower = 0, upper = 1> cloglog;
  int<lower = 0, upper = 1> rho_mu;
  int<lower = 0, upper = 4> likelihood;
  //--- environmental data ----
  int<lower = 1> K_z;
  matrix[N, K_z] Z;
}
transformed data {
}
parameters {
  vector[N] mu;
  vector[K_z] beta_t;
  array[rho_mu] real lxi;
  array[likelihood == 0 ? 1 : 0] real<lower = 0> sigma_obs;
  array[likelihood > 0 ? 1 : 0] real<lower = 0> phi;
}
transformed parameters {
}
generated quantities {
  vector[N] log_lik;
  {
    array[rho_mu] real xi;
    if (rho_mu)
      xi = - exp(lxi);
    vector[N] rho;
    // rho now hasa "regression like" type
    if (cloglog) {
      if (rho_mu) {
        rho =
          inv_cloglog(Z * beta_t + xi[1] .* log(mu));
      } else {
        rho =
          inv_cloglog(Z * beta_t);
      }
    } else {
      if (rho_mu) {
        rho =
          inv_logit(Z * beta_t + xi[1] .* log(mu));
      } else {
        rho =
          inv_logit(Z * beta_t);
      }
    }
    for (n in 1:N) {
      int is_zero = 0;
      if (y[n] == 0) {
        is_zero += 1;
      }
      log_lik[n] = ptziloglik_lpdf(y[n] | likelihood, is_zero,
                                   mu[n], rho[n],
                                   likelihood == 0 ? sigma_obs[1] : phi[1]);
    }
  }
}
